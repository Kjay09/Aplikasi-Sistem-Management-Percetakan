package model;

public class DetailPemesananData extends DetailPemesanan{

    public DetailPemesananData() {
        super();
    }

    public DetailPemesananData(String idProdukPesanan) {
        super(idProdukPesanan);
    }
    
}
